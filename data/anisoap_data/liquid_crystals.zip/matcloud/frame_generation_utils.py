import freud
import numpy as np
import rowan
from ase import Atoms
from scipy.stats.qmc import Sobol
from skmatter.sample_selection import FPS


def gen_constrained_orientations(constraint_amount, n, identity=[1, 0, 0, 0]):
    identity_quats = np.array([identity] * n)
    return rowan.interpolate.slerp(
        identity_quats, rowan.random.rand(n), constraint_amount
    )


def make_frame(points, orientations, box):
    frame = Atoms(cell=box, positions=points, numbers=np.zeros(len(points)), pbc=True)
    frame.arrays["quaternions"] = orientations
    return frame


def nematic_from_ase(frame, n=[1, 0, 0]):
    orientations = frame.arrays["quaternions"]
    nop = freud.order.Nematic(n)
    nop.compute(orientations)
    return nop.order


def make_smectic(box, N, a, L):
    N_layers = int(box[0] / (2 * a))
    N_in_layer = N // N_layers + 1
    dlayer = 2 * a
    layers = np.ones(N, dtype=int)

    my_frames = []
    for i in np.linspace(0.0, 1.0, 100):
        layer_noise = i / 2.0
        for _ in range(5):
            smectic_points = np.zeros((N, 3))
            for l in range(N_layers):
                N_gen = int(min(len(smectic_points) - (l) * N_in_layer, N_in_layer))
                if N_gen > 0:
                    p = np.multiply(L, Sobol(2).random_base2(m=int(np.log2(N_gen)) + 2))
                    p += np.random.uniform(-layer_noise, layer_noise, size=p.shape)
                    fps = FPS(n_to_select=N_gen).fit(p)
                    smectic_points[
                        l * N_in_layer : l * N_in_layer + N_gen, 0
                    ] = dlayer * l + np.random.uniform(
                        -dlayer * layer_noise, dlayer * layer_noise, size=N_gen
                    )
                    smectic_points[l * N_in_layer : l * N_in_layer + N_gen, 1:] = p[
                        fps.selected_idx_
                    ]
                    layers[l * N_in_layer : l * N_in_layer + N_gen] = l
            orientations = gen_constrained_orientations(i)
            my_frame = make_frame(smectic_points, orientations, box)
            my_frame.info["phase"] = "S"
            my_frame.arrays["layer"] = layers
            my_frames.append(my_frame)

    return my_frames


def make_nematic(box, N, orientations):
    my_frames = []
    for o in orientations:
        nematic_points = Sobol(3).random_base2(m=int(np.log2(N)) + 2)
        nematic_points += np.random.uniform(-0.1, 0.1, size=nematic_points.shape)
        fps = FPS(n_to_select=N).fit(nematic_points)
        my_frames.append(
            make_frame(nematic_points[fps.selected_idx_] @ np.diag(box), o)
        )
    for frame in my_frames:
        frame.info["phase"] = "N"
    return my_frames

import os

import freud
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from anisoap.representations import EllipsoidalDensityProjection
from anisoap.utils import ClebschGordanReal, cg_combine, standardize_keys
from ase.io import read
from chemiscope import write_input
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from sklearn.decomposition import PCA
from skmatter.metrics import global_reconstruction_error
from skmatter.preprocessing import StandardFlexibleScaler
from tqdm.auto import tqdm

import frame_generation_utils as fgu

l_max = 6
n_max = 6

major = 3.0
minor = 1.0

cutoff_radius = 6.2
radial_gaussian_width = 3.0

representation = EllipsoidalDensityProjection(
    max_angular=l_max,
    max_radial=n_max,
    radial_basis_name="gto",
    rotation_type="quaternion",
    rotation_key="quaternions",
    cutoff_radius=cutoff_radius,
    radial_gaussian_width=radial_gaussian_width,
    basis_rcond=1e-6,
    basis_tol=1e-3,
)


def ql_from_ase(frame, l_max=l_max):
    box = freud.box.Box.from_matrix(frame.cell[:])
    L = np.min(np.linalg.norm(frame.cell[:], axis=1))
    if L < cutoff_radius:
        frame = frame.copy().repeat(2)
        box = freud.box.Box.from_matrix(frame.cell[:])
        L = cutoff_radius

    points = frame.positions
    x = np.zeros((len(frame), l_max + 1))
    for l in range(0, l_max + 1):
        ql = freud.order.Steinhardt(l=l, weighted=True, wl=True)
        ql.compute((box, points), {"r_max": min(L / 2.1, cutoff_radius)})
        x[:, l] = ql.particle_order
    return x


def make_features(args):
    frame, mycg = args
    i = frame.info["idx"]

    if os.path.exists("separated_features/x_raw_{}.npy".format(i)):
        x_raw = np.load("separated_features/x_raw_{}.npy".format(i))
        if os.path.exists("separated_features/x_radial_{}.npy".format(i)):
            x_radial = np.load("separated_features/x_radial_{}.npy".format(i))
            return x_raw, x_radial

    if os.path.exists("x_raw.npy"):
        x_raw = np.load("x_raw.npy")
    else:
        x_raw = None

    if os.path.exists("x_radial.npy"):
        x_radial = np.load("x_radial.npy")
    else:
        x_radial = None

    if x_raw is None or np.count_nonzero(x_raw[i]) == 0:
        rep_raw = representation.transform([frame], show_progress=False)

        aniso_nu1 = standardize_keys(rep_raw)
        aniso_nu2 = cg_combine(
            aniso_nu1,
            aniso_nu1,
            clebsch_gordan=mycg,
            lcut=0,
            other_keys_match=["types_center"],
        )
        x_raw_i = aniso_nu2.block().values.squeeze()
        x_radial_i = aniso_nu1.block(angular_channel=0).values.squeeze()
        np.save("separated_features/x_radial_{}.npy".format(i), x_radial_i)
        np.save("separated_features/x_raw_{}.npy".format(i), x_raw_i)
        return x_raw_i, x_radial_i
    else:
        return x_raw[i], x_radial[i]


if __name__ == "__main__":
    mycg = ClebschGordanReal(l_max)
    frames = read("smectic.xyz", ":")
    orientations = [frame.arrays["quaternions"] for frame in frames]
    frames = [*frames, *read("nematic.xyz", ":")]

    for frame in frames:
        if "c_diameter1" in frame.arrays:
            _ = frame.arrays.pop("c_diameter1")
        if "c_diameter2" in frame.arrays:
            _ = frame.arrays.pop("c_diameter2")
        if "c_diameter3" in frame.arrays:
            _ = frame.arrays.pop("c_diameter3")

    for frame in frames:
        frame.arrays["c_diameter[1]"] = 2 * major * np.ones(len(frame))
        frame.arrays["c_diameter[2]"] = 2 * minor * np.ones(len(frame))
        frame.arrays["c_diameter[3]"] = 2 * minor * np.ones(len(frame))

    n_mid = len(frames)
    n_frames = len(frames)
    ellipsoid_type = [
        "p" if frame.arrays["c_diameter[1]"][0] == 2 * major else "o"
        for frame in frames
    ]

    nop_sys = np.array([fgu.nematic_from_ase(f) for f in tqdm(frames)])
    nop_part = np.array([nn for nn, frame in zip(nop_sys, frames) for _ in frame])

    if not os.path.exists("x_raw.npy") and not os.path.exists("x_radial.npy"):
        results = [make_features((frame, mycg)) for i, frame in enumerate(tqdm(frames))]

        x_raw = np.array([r[0] for r in results])
        x_radial = np.array([r[1] for r in results])

        np.save("x_raw.npy", x_raw)
        np.save("x_radial.npy", x_radial)

    x_raw = np.load("x_raw.npy")
    x_radial = np.load("x_radial.npy")

    x_part = StandardFlexibleScaler(column_wise=False).fit_transform(
        x_raw.copy().reshape(-1, x_raw.shape[-1])
    )
    x_struct = StandardFlexibleScaler(column_wise=False).fit_transform(
        x_raw.mean(axis=1)
    )

    pca = PCA(n_components=6)
    pca_anisoap = pca.fit_transform(x_struct)

    x_rad_part = StandardFlexibleScaler(column_wise=False).fit_transform(
        x_radial.copy().reshape(-1, x_radial.shape[-1])
    )
    x_rad_struct = StandardFlexibleScaler(column_wise=False).fit_transform(
        x_radial.mean(axis=1)
    )

    x_part_oblate = x_part[:n_mid]
    x_struct_oblate = x_struct[:n_mid]
    pca_anisoap_oblate = pca_anisoap[:n_mid]

    x_rad_part_oblate = x_rad_part[:n_mid]
    x_rad_struct_oblate = x_rad_struct[:n_mid]

    x_part_prolate = x_part[n_mid:]
    x_struct_prolate = x_struct[n_mid:]
    pca_anisoap_prolate = pca_anisoap[n_mid:]

    x_rad_part_prolate = x_rad_part[n_mid:]
    x_rad_struct_prolate = x_rad_struct[n_mid:]

    ql_feat = np.array([ql_from_ase(frame) for frame in tqdm(frames)])
    ql_feat[np.isnan(ql_feat)] = 0
    try:
        ql_feat_struct = StandardFlexibleScaler(column_wise=False).fit_transform(
            np.mean(ql_feat, axis=1)
        )
    except ValueError:
        # if our dataset is positionally degenerate, then ValueError will be flagged
        ql_feat_struct = np.mean(ql_feat, axis=1)

    pca = PCA(n_components=min(6, ql_feat_struct.shape[1]))
    pca_ql = pca.fit_transform(ql_feat_struct)

    fig = plt.figure(figsize=(6, 6), layout="constrained")

    ax_dict = fig.subplot_mosaic(
        """
        A
        y
        z
        
        """,
        height_ratios=(2, 0.1, 0.1),
        # width_ratios=(1, 4, 1),
        # sharex=True,
        # sharey=True,
    )

    ax_pca = ax_dict["A"]
    ax_pca_ql = inset_axes(ax_pca, height="35%", width="30%", loc=1)

    w = [np.arange(0, len(frames) // 2), np.arange(len(frames) // 2, len(frames))]

    kwargs = dict(edgecolor="k", linewidth=0.5, vmin=0, vmax=1, rasterized=True)
    ax_pca.scatter(
        pca_anisoap[w[0]][:, 0],
        pca_anisoap[w[0]][:, 1],
        c=nop_sys[w[0]],
        cmap="Reds",
        label="Smectic",
        s=10,
        **kwargs
    )
    ax_pca.scatter(
        pca_anisoap[w[1]][:, 0],
        pca_anisoap[w[1]][:, 1],
        c=nop_sys[w[0]],
        cmap="Blues",
        label="Nematic",
        s=10,
        **kwargs
    )
    ax_pca.set_xlabel(r"PC$_1$ of X$_{AniSOAP}$")
    ax_pca.set_ylabel(r"PC$_2$ of X$_{AniSOAP}$")
    ax_pca_ql.scatter(
        pca_ql[w[0]][:, 0],
        pca_ql[w[0]][:, 1],
        c=nop_sys[w[0]],
        cmap="Reds",
        label="Smectic",
        s=4,
        **kwargs
    )
    ax_pca_ql.scatter(
        pca_ql[w[1]][:, 0],
        pca_ql[w[1]][:, 1],
        c=nop_sys[w[0]],
        cmap="Blues",
        label="Nematic",
        s=4,
        **kwargs
    )
    ax_pca_ql.set_xlabel(r"PC$_1$ of X$_{SOP}$")
    ax_pca_ql.set_ylabel(r"PC$_2$ of X$_{SOP}$")

    norm = mpl.colors.Normalize(vmin=0, vmax=1)
    cbar = plt.colorbar(
        mpl.cm.ScalarMappable(norm=norm, cmap="Reds"),
        cax=ax_dict["y"],
        fraction=0.1,
        orientation="horizontal",
    )
    cbar.set_ticks([])
    ax_dict["y"].annotate(
        "Smectic", xy=(1.01, 0.5), xycoords="axes fraction", va="center", ha="left"
    )
    cbar = plt.colorbar(
        mpl.cm.ScalarMappable(norm=norm, cmap="Blues"),
        cax=ax_dict["z"],
        fraction=0.1,
        orientation="horizontal",
        label="Orientational Order Parameter",
    )
    cbar.set_ticks([0, 1])
    ax_dict["z"].annotate(
        "Nematic", xy=(1.01, 0.5), xycoords="axes fraction", va="center", ha="left"
    )

    subfigs = os.listdir("raw_figures/subfigures")
    ies = [int(fn.split("-")[2].split(".")[0].split(" ")[0]) - 1 for fn in subfigs]

    for ii in np.argsort(ies):
        fn = subfigs[ii]
        i = ies[ii]
        ax_pca.scatter(
            pca_anisoap[i][0],
            pca_anisoap[i][1],
            fc="none",
            s=200,
            edgecolor="k",
            linewidth=2,
        )
        ax_pca_ql.scatter(pca_ql[i][0], pca_ql[i][1], fc="none", s=200, edgecolor="k")
        ax_pca.scatter(
            pca_anisoap[i][0],
            pca_anisoap[i][1],
            c=nop_sys[i],
            cmap="Reds" if i in w[0] else "Blues",
            s=50,
            **kwargs
        )
        ax_pca_ql.scatter(
            pca_ql[i][0],
            pca_ql[i][1],
            c=nop_sys[i],
            cmap="Reds" if i in w[0] else "Blues",
            s=50,
            **kwargs
        )
    fig.subplots_adjust(wspace=0.0, hspace=0.0)
    plt.savefig("raw_figures/lc.eps")
    plt.show()

    plt.figure(figsize=(6, 6))
    feats = {
        "$X_{OOP}$": np.array(nop_sys).reshape(-1, 1),
        "$X_{SOP}$": ql_feat_struct,
        "$X_\\text{AniSOAP}^{(\\nu=1)}$": x_rad_struct,
        "$X_\\text{AniSOAP}^{(\\nu=2)}$": x_struct,
    }

    arr = np.zeros((len(feats.keys()), len(feats.keys())))
    for i, (key1, val1) in enumerate(feats.items()):
        for j, (key2, val2) in enumerate(feats.items()):
            arr[j, i] = global_reconstruction_error(val1, val2)
    plt.imshow(arr, cmap="Reds")
    plt.gca().set_xticks(range(arr.shape[0]))
    plt.gca().set_yticks(range(arr.shape[0]))
    plt.gca().set_xticklabels(feats.keys(), fontsize=10)
    plt.gca().set_yticklabels(feats.keys(), fontsize=10)
    for i, (key1, val1) in enumerate(feats.items()):
        for j, (key2, val2) in enumerate(feats.items()):
            plt.text(
                i,
                j,
                s=round(50 * arr[j, i]),
                ha="center",
                va="center",
                fontsize=14,
                color="k" if arr[j, i] < 0.5 else "w",
            )

    plt.gca().set_ylabel("$X_{target}$", fontsize=14)
    plt.gca().set_xlabel("$X_{input}$", fontsize=14)
    plt.title("GFRE($X_{input}$, $X_{target}$) [%]", size=14)

    plt.tight_layout()
    plt.savefig("../../figures/lc_gfre.pdf")
    plt.show()

    shape = dict(
        kind="ellipsoid",
        parameters={
            "structure": [
                {
                    "semiaxes": [
                        frame.arrays["c_diameter[1]"][0] / 2.0,
                        frame.arrays["c_diameter[2]"][0] / 2.0,
                        frame.arrays["c_diameter[3]"][0] / 2.0,
                    ],
                    "scale": 1.0,
                }
                for frame in frames
            ],
            "atom": [
                {
                    "orientation": [
                        *frames[i].arrays["quaternions"][j][1:],
                        frames[i].arrays["quaternions"][j][0],
                    ]
                }
                for i in range(n_frames)
                for j in range(len(frames[i]))
            ],
        },
    )

    write_input(
        "../../figures/si/liquid_crystals.json",
        frames=frames,
        properties={
            "t": pca_anisoap,
            "t_q": pca_ql,
            "phase": [frame.info["phase"] for frame in frames],
            "nematic_op": nop_sys,
        },
        settings={
            "map": {
                "x": {"property": "t[1]"},
                "y": {"property": "t[2]"},
                "z": {"property": "t[3]"},
                "symbol": "phase",
                "color": {"property": "nematic_op"},
            },
            "structure": [{"shape": "ellipsoid"}],
        },
        shapes={"ellipsoid": shape},
    )

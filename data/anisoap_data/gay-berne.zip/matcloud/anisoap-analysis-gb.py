import warnings
from pathlib import Path

import metatensor
import numpy as np
from anisoap.representations import EllipsoidalDensityProjection
from anisoap.utils import ClebschGordanReal, cg_combine, standardize_keys
from ase.io import read
from chemiscope import write_input
from matplotlib import pyplot as plt
from PIL import Image
from sklearn.decomposition import PCA
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error as mse
from sklearn.model_selection import learning_curve, train_test_split
from skmatter.preprocessing import StandardFlexibleScaler

lmax = 10
nmax = 10
cutoff_radius = 10.0
rgw = 2.0
rcond = 1e-6
normalize = True


def rmse(*x):
    return np.sqrt(mse(*x))


frames = read("./char_curves.xyz", "::")
energies = [frame.info["energy"] for frame in frames]
h12s = [frame.info["h12"] for frame in frames]
energies = np.asarray(energies).reshape(-1, 1)
h12s = np.asarray(h12s).reshape(-1, 1)
print(len(frames), energies.shape, h12s.shape)

# The arrays and info associated with each frame
print("Arrays:", frames[0].arrays, "Info:", frames[0].info)


distances = [frame.info["d"] for frame in frames]
fig, axs = plt.subplots(nrows=1, ncols=2, figsize=(12, 4), squeeze=True, layout=None)
axs[0].scatter(distances, energies)
axs[0].plot([min(distances), max(distances)], [0, 0], "r--")
axs[0].set_title("Energy Wells")
axs[0].set_xlabel("Intercenter Distance")
axs[0].set_ylabel("Energy/$\epsilon$")
axs[1].hist(energies, bins=100)
axs[1].set_title("Distribution of Energies")
axs[1].set_xlabel("Energy/$\epsilon$")
axs[1].set_ylabel("Counts")
plt.show()

for frame in frames:
    frame.arrays["c_diameter[1]_original"] = frame.arrays["c_diameter[1]"]
    frame.arrays["c_diameter[2]_original"] = frame.arrays["c_diameter[2]"]
    frame.arrays["c_diameter[3]_original"] = frame.arrays["c_diameter[3]"]

for frame in frames:
    frame.arrays["c_diameter[1]"] = 1.0 * frame.arrays["c_diameter[1]_original"]
    frame.arrays["c_diameter[2]"] = 1.0 * frame.arrays["c_diameter[2]_original"]
    frame.arrays["c_diameter[3]"] = 1.0 * frame.arrays["c_diameter[3]_original"]


fname = "rep_raw_allscale_lmaxnmax10_rgw2.0_every1_theta1phixphiyphiz5_abc21.51_mind1.5_maxd4.5_anisoap2_rad-2.npz"
if Path(fname).exists():
    rep_raw = metatensor.load(fname)
else:
    representation = EllipsoidalDensityProjection(
        max_angular=lmax,
        max_radial=nmax,
        radial_basis_name="gto",
        rotation_type="quaternion",
        rotation_key="quaternions",
        cutoff_radius=cutoff_radius,
        radial_gaussian_width=rgw,
        basis_tol=1e-2,
    )
    rep_raw = representation.transform(frames, normalize=True, show_progress=True)
    rep_raw.save(fname)
    
aniso_nu1 = standardize_keys(rep_raw)
mycg = ClebschGordanReal(lmax)
aniso_nu2 = cg_combine(
    aniso_nu1, aniso_nu1, clebsch_gordan=mycg, lcut=0, other_keys_match=["types_center"]
)
aniso_nu2 = metatensor.operations.sum_over_samples(aniso_nu2, sample_names="center")
plt.title(f"Aniso Nu1")
plt.plot(aniso_nu1.block(0).values.squeeze().T)
plt.show()

x_raw = aniso_nu2.block(0).values.squeeze()
plt.plot(x_raw.T)
plt.title("Nontandardized Power Spectrum")
x_raw = x_raw[:, x_raw.var(axis=0) > 1e-12]
column_wise = False
x_scaler = StandardFlexibleScaler(column_wise=column_wise).fit(x_raw)
x = x_scaler.transform(x_raw)
print(x.shape)
print(np.linalg.matrix_rank(x))
plt.plot(x.T)
plt.title(f"Standardized Power Spectrum\n{normalize=},{column_wise=}")

# First fit energies
y_scaler = StandardFlexibleScaler(column_wise=True).fit(energies)
y = y_scaler.transform(energies)
i_train, i_test = train_test_split(np.arange(y.shape[0]), test_size=0.1, random_state=2)
lr = RidgeCV(cv=5, alphas=np.logspace(-12, -2, 5), fit_intercept=False)
lr.fit(x[i_train], y[i_train])
energies_pred = y_scaler.inverse_transform(lr.predict(x))
energies_r2_train = lr.score(x[i_train], y[i_train])
energies_r2_test = lr.score(x[i_test], y[i_test])
energies_rmse_train = rmse(energies_pred[i_train], energies[i_train])
energies_rmse_test = rmse(energies_pred[i_test], energies[i_test])
print(
    f"{energies_r2_train=:.3f}\n{energies_r2_test=:.3f}\n{energies_rmse_train=:.3f}\n{energies_rmse_test=:.3f}"
)
print(f"{lr.alpha_=}")

# Next fit h12s
y_scaler = StandardFlexibleScaler(column_wise=True).fit(h12s)
y = y_scaler.transform(h12s)
i_train, i_test = train_test_split(np.arange(y.shape[0]), test_size=0.2, random_state=1)
lr = RidgeCV(cv=5, alphas=np.logspace(-12, -2, 5), fit_intercept=False)

lr.fit(x[i_train], y[i_train])
h12s_pred = y_scaler.inverse_transform(lr.predict(x))
h12s_r2_train = lr.score(x[i_train], y[i_train])
h12s_r2_test = lr.score(x[i_test], y[i_test])
h12s_rmse_train = rmse(h12s_pred[i_train], h12s[i_train])
h12s_rmse_test = rmse(h12s_pred[i_test], h12s[i_test])
print(
    f"{h12s_r2_train=:.3f}\n{h12s_r2_test=:.3f}\n{h12s_rmse_train=:.3f}\n{h12s_rmse_test=:.3f}\n{lr.alpha_=}"
)
y_scaler = StandardFlexibleScaler(column_wise=True).fit(h12s)
y = y_scaler.transform(h12s)
i_train, i_test = train_test_split(np.arange(y.shape[0]), test_size=0.2, random_state=1)
lr = RidgeCV(cv=5, alphas=np.logspace(-25, -2, 5), fit_intercept=False)
lr.fit(x[i_train], y[i_train])

pca = PCA(n_components=244)
t_pca = pca.fit_transform(x)
y_scaler = StandardFlexibleScaler(column_wise=True).fit(h12s)
y = y_scaler.transform(h12s)
i_train, i_test = train_test_split(np.arange(y.shape[0]), test_size=0.2, random_state=1)
lr = RidgeCV(cv=5, alphas=np.logspace(-12, -2, 5), fit_intercept=False)
lr.fit(t_pca[i_train], y[i_train])


def plot_energy_wells(ax, phi_x, phi_y, phi_z):
    d = [
        frame.info["d"]
        for frame in frames
        if np.allclose(
            (frame.info["phi_x"], frame.info["phi_y"], frame.info["phi_z"]),
            (phi_x, phi_y, phi_z),
        )
    ]
    energies = [
        frame.info["energy"]
        for frame in frames
        if np.allclose(
            (frame.info["phi_x"], frame.info["phi_y"], frame.info["phi_z"]),
            (phi_x, phi_y, phi_z),
        )
    ]
    print(len(d), len(energies))
    ax.plot(d, energies)


img = np.asarray(Image.open("./demofig8_1_1.5_2.png"))
fig, axs = plt.subplot_mosaic(
    [["A", "B"], ["C", "D"]], layout="tight", figsize=(6.6, 6)
)
axs["A"].imshow(img)
axs["A"].axis("off")
plot_energy_wells(axs["B"], 0, 0, 0)
plot_energy_wells(axs["B"], 0.25 * np.pi / 2, 0.5 * np.pi / 2, 0.5 * np.pi / 2)
plot_energy_wells(axs["B"], 0, np.pi / 2, 0)
axs["B"].legend(
    [
        f"(0,0,0)",
        "$(\\frac{\pi}{8}, \\frac{\pi}{4}, \\frac{\pi}{4})$",
        "(0,$\\frac{\pi}{2}$,0)",
    ],
    handlelength=0.75,
)
axs["B"].plot([min(distances), max(distances)], [0, 0], "r--")
axs["B"].set_xlabel("Inter-center Distance d $[\sigma]$")
axs["B"].set_ylabel("Energy $[\epsilon]$")
axs["C"].scatter(h12s[i_test], h12s_pred[i_test], alpha=0.5)
axs["C"].plot([h12s.min(), h12s.max()], [h12s.min(), h12s.max()], "k--")
axs["C"].set_xlabel("Ground Truth $h_{12}$ $[\sigma]$")
axs["C"].set_ylabel("Predicted $h_{12} [\sigma]$")
axs["C"].annotate(
    xy=(0.05, 0.82),
    text=r"scores (train, test)"
    + f"\n$R^2 = $({h12s_r2_train:.3f},{h12s_r2_test:.3f})",
    bbox=dict(facecolor="aliceblue", edgecolor="grey", boxstyle="round"),
    xycoords="axes fraction",
)
axs["D"].scatter(energies[i_test], energies_pred[i_test], alpha=0.5)
axs["D"].plot([energies.min(), energies.max()], [energies.min(), energies.max()], "k--")
axs["D"].set_xlabel("Ground Truth Energy $[\epsilon]$")
axs["D"].set_ylabel("Predicted Energy $[\epsilon]$", labelpad=-5)
axs["D"].annotate(
    xy=(0.05, 0.75),
    text=r"scores (train, test)"
    + f"\n$R^2 = $({energies_r2_train:.3f},{energies_r2_test:.3f})"
    + f"\n$RMSE = $({energies_rmse_train:.3f},{energies_rmse_test:.3f})",
    bbox=dict(facecolor="aliceblue", edgecolor="grey", boxstyle="round"),
    xycoords="axes fraction",
)
fig.savefig("gb_h12_parity_4fer2.pdf")
plt.show()


print("Generating Learning Curves (~20 min total)")
y_scaler = StandardFlexibleScaler(column_wise=True).fit(h12s)
y = y_scaler.transform(h12s)
lr = RidgeCV(cv=5, alphas=np.logspace(-12, -2, 5), fit_intercept=False)
with warnings.catch_warnings():
    warnings.filterwarnings("ignore")
    train_size_abs_h12, train_scores_h12, test_scores_h12 = learning_curve(
        lr,
        t_pca,
        y,
        train_sizes=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
        shuffle=True,
        cv=5,
        random_state=2,
    )

plt.plot(train_size_abs_h12, test_scores_h12.mean(axis=1), label="Test", alpha=0.7)
plt.fill_between(
    train_size_abs_h12,
    test_scores_h12.min(axis=1),
    test_scores_h12.max(axis=1),
    alpha=0.3,
)
plt.plot(
    train_size_abs_h12,
    train_scores_h12.mean(axis=1),
    label="Train",
    linestyle=(0, (5, 10)),
)
plt.fill_between(
    train_size_abs_h12,
    train_scores_h12.min(axis=1),
    train_scores_h12.max(axis=1),
    alpha=0.3,
)
plt.xlabel("$N_{train}$")
plt.ylabel("Score ($R^2$)")
plt.ylim(0, 1.1)
plt.legend()

plt.title("Learning Curve for $h_{12}$")
plt.show()

y_scaler = StandardFlexibleScaler(column_wise=True).fit(energies)
y = y_scaler.transform(energies)
rng = np.random.default_rng(12345)
i_permute = rng.permutation(y.shape[0])
lr = RidgeCV(cv=5, alphas=np.logspace(-12, -2, 5), fit_intercept=False)

with warnings.catch_warnings():
    warnings.filterwarnings("ignore")
    (
        train_size_abs_energies2,
        train_scores_energies2,
        test_scores_energies2,
    ) = learning_curve(
        lr,
        t_pca[i_permute],
        y[i_permute],
        train_sizes=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
        shuffle=True,
        random_state=2390,
        cv=5,
    )
test_scores_energies2
plt.plot(train_size_abs_energies2, test_scores_energies2.mean(axis=1), label="Test")
plt.fill_between(
    train_size_abs_energies2,
    test_scores_energies2.min(axis=1),
    test_scores_energies2.max(axis=1),
    alpha=0.3,
)
plt.plot(train_size_abs_energies2, train_scores_energies2.mean(axis=1), label="Train")
plt.fill_between(
    train_size_abs_energies2,
    train_scores_energies2.min(axis=1),
    train_scores_energies2.max(axis=1),
    alpha=0.3,
)
plt.xlabel("$N_{train}$")
plt.ylabel("Score ($R^2$)")
plt.legend(loc="lower right")

plt.title("Learning Curve for GB Energy")
plt.show()

# Plot both side-by-side and export
fig, axs = plt.subplots(1, 2, layout="tight", figsize=(8, 4), sharey=True, sharex=True)
axs[0].plot(train_size_abs_h12, test_scores_h12.mean(axis=1), label="Test", alpha=0.7)
axs[0].fill_between(
    train_size_abs_h12,
    test_scores_h12.min(axis=1),
    test_scores_h12.max(axis=1),
    alpha=0.3,
)
axs[0].plot(
    train_size_abs_h12,
    train_scores_h12.mean(axis=1),
    label="Train",
    linestyle=(0, (5, 10)),
)
axs[0].fill_between(
    train_size_abs_h12,
    train_scores_h12.min(axis=1),
    train_scores_h12.max(axis=1),
    alpha=0.3,
)
axs[0].set_ylim(0.98, 1.02)
axs[0].legend(fontsize=12)
axs[0].set_title("$h_{12}$", fontsize=14)
axs[0].set_ylabel("$R^2$", fontsize=14)
axs[0].set_xlabel("$N_{train}$", fontsize=14)
axs[0].tick_params(axis="both", which="major", labelsize=12)
axs[1].plot(train_size_abs_energies2, test_scores_energies2.mean(axis=1), label="Test")
axs[1].fill_between(
    train_size_abs_energies2,
    test_scores_energies2.min(axis=1),
    test_scores_energies2.max(axis=1),
    alpha=0.3,
)
axs[1].plot(
    train_size_abs_energies2, train_scores_energies2.mean(axis=1), label="Train"
)
axs[1].fill_between(
    train_size_abs_energies2,
    train_scores_energies2.min(axis=1),
    train_scores_energies2.max(axis=1),
    alpha=0.3,
)
axs[1].set_ylim(0.98, 1.01)
axs[1].legend(fontsize=12)
axs[1].set_title("Energy", fontsize=14)
axs[1].set_xlabel("$N_{train}$", fontsize=14)
axs[1].set_xticks(ticks=[2500, 7500, 12500, 17500])
axs[1].tick_params(axis="both", which="major", labelsize=12)
fig.savefig("gb_learning_curve2.pdf")
plt.show()

# PCA On features
pca = PCA(n_components=3)
t_pca = pca.fit_transform(x)
plt.scatter(t_pca[:, 0], t_pca[:, 1], c=energies)
plt.title("pca on features")
print(pca.explained_variance_ratio_)

ellipsoids = {
    "kind": "ellipsoid",
    "parameters": {
        "global": {},
        "structure": [
            {
                "semiaxes": [
                    frame.arrays["c_diameter[1]"][0],
                    frame.arrays["c_diameter[2]"][0],
                    frame.arrays["c_diameter[3]"][0],
                ]
            }
            for _ in frames
        ],
        "atom": [
            {"orientation": np.roll(o, -1).tolist()}
            for frame in frames
            for o in frame.arrays["quaternions"]
        ],
    },
}

properties_dict = {}
properties_dict["T (PCA, AniSOAP)"] = t_pca
properties_dict["energy"] = energies
properties_dict["energy_errors"] = np.abs(energies.flatten() - energies_pred.flatten())
properties_dict["anisoap_energies"] = energies_pred.flatten()
properties_dict["d"] = distances
properties_dict["h12"] = h12s
properties_dict["anisoap_h12"] = h12s_pred.flatten()
properties_dict["phi_x"] = [frame.info["phi_x"] for frame in frames]
properties_dict["phi_y"] = [frame.info["phi_y"] for frame in frames]
properties_dict["theta"] = [frame.info["theta"] for frame in frames]
shapes = {"ellipsoid": ellipsoids}
write_input(
    "char_curves.json", frames=frames, properties=properties_dict, shapes=shapes
)
